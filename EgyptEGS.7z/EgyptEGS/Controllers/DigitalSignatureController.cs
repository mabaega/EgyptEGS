﻿using System.Security.Cryptography;
using System.Security.Cryptography.Pkcs;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using Net.Pkcs11Interop.Common;
using Net.Pkcs11Interop.HighLevelAPI;
using Org.BouncyCastle.Asn1;
using Org.BouncyCastle.Asn1.Ess;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;
using System.IO;

namespace EgyptEGS.Controllers
{
    public class DigitalSignatureController : Controller
    {
        private string DllLibPath = "eps2003csp11.dll"; // Default driver path
        private string TokenCertificate = "Egypt Trust Sealing CA";
        private readonly ILogger<DigitalSignatureController> _logger;

        public DigitalSignatureController(ILogger<DigitalSignatureController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost("SignDocument")]
        public IActionResult SignDocument([FromBody] SignRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.Pin) || string.IsNullOrEmpty(request.Document) || (string.IsNullOrEmpty(request.UsbToken) && string.IsNullOrEmpty(request.PfxFile)))
                {
                    return Json(new { success = false, message = "All fields are required." });
                }

                _logger.LogInformation("Signing document using USB token or PFX: {0}", request.UsbToken ?? "PFX");

                if (!string.IsNullOrEmpty(request.UsbToken))
                {
                    IdentifyDriver(request);
                }

                if (!string.IsNullOrEmpty(request.PfxFile) && string.IsNullOrEmpty(request.PfxPassword))
                {
                    return Json(new { success = false, message = "Password is required for PFX file." });
                }

                string signedDocument = SignWithCms(request.Document, request.Pin, request.PfxFile, request.PfxPassword, out var certificateInfo);

                return Json(new { success = true, message = "Document signed successfully!", signedDocument, certificateInfo });

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error signing document");
                return Json(new { success = false, message = ex.Message });
            }
        }

        private void IdentifyDriver(SignRequest request)
        {
            switch (request.UsbToken)
            {
                case "ePass2003":
                    DllLibPath = "eps2003csp11.dll";
                    TokenCertificate = "Egypt Trust Sealing CA";
                    break;
                case "WD_PROXKEY":
                    DllLibPath = "aetpkss1.dll";
                    TokenCertificate = "WD_PROXKEY CA";
                    break;
                case "Egypt Trust":
                    DllLibPath = "eps2003csp11.dll";
                    TokenCertificate = "Egypt Trust Sealing CA";
                    break;
                default:
                    throw new Exception("Unsupported USB token type");
            }
        }

        private byte[] HashBytes(byte[] input)
        {
            using (SHA256 sha = SHA256.Create())
            {
                return sha.ComputeHash(input);
            }
        }

        private string SignWithCms(string serializedJson, string tokenPin, string pfxFile, string pfxPassword, out object certificateInfo)
        {
            byte[] data = Encoding.UTF8.GetBytes(serializedJson);
            X509Certificate2 certForSigning = !string.IsNullOrEmpty(pfxFile) ? GetCertificateFromPfx(pfxFile, pfxPassword) : GetCertificate();

            certificateInfo = new
            {
                Subject = certForSigning.Subject,
                Issuer = certForSigning.Issuer,
                SerialNumber = certForSigning.SerialNumber,
                NotBefore = certForSigning.NotBefore,
                NotAfter = certForSigning.NotAfter,
                Thumbprint = certForSigning.Thumbprint
            };

            ContentInfo content = new ContentInfo(new Oid("1.2.840.113549.1.7.5"), data);
            SignedCms cms = new SignedCms(content, true);
            CmsSigner signer = new CmsSigner(certForSigning);
            signer.DigestAlgorithm = new Oid("2.16.840.1.101.3.4.2.1");
            signer.SignedAttributes.Add(new Pkcs9SigningTime(DateTime.UtcNow));

            EssCertIDv2 bouncyCertificate = new EssCertIDv2(new Org.BouncyCastle.Asn1.X509.AlgorithmIdentifier(new DerObjectIdentifier("1.2.840.113549.1.9.16.2.47")), HashBytes(certForSigning.RawData));
            SigningCertificateV2 signerCertificateV2 = new SigningCertificateV2(new EssCertIDv2[] { bouncyCertificate });
            signer.SignedAttributes.Add(new AsnEncodedData(new Oid("1.2.840.113549.1.9.16.2.47"), signerCertificateV2.GetEncoded()));

            cms.ComputeSignature(signer);
            return Convert.ToBase64String(cms.Encode());
        }

        private X509Certificate2 GetCertificate()
        {
            X509Store store = new X509Store(StoreName.My, StoreLocation.CurrentUser);
            store.Open(OpenFlags.MaxAllowed);
            var foundCerts = store.Certificates.Find(X509FindType.FindByIssuerName, TokenCertificate, false);
            store.Close();
            if (foundCerts.Count == 0) throw new Exception("No valid certificate found");
            return foundCerts[0];
        }

        private X509Certificate2 GetCertificateFromPfx(string pfxFile, string password)
        {
            if (!System.IO.File.Exists(pfxFile))
                throw new Exception("PFX file not found");

            return new X509Certificate2(pfxFile, password, X509KeyStorageFlags.MachineKeySet);
        }
    }

    public class SignRequest
    {
        public string Pin { get; set; }
        public string Document { get; set; }
        public string UsbToken { get; set; }
        public string PfxFile { get; set; }
        public string PfxPassword { get; set; }
    }
}
