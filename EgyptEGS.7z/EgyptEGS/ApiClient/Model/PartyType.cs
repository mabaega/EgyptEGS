﻿namespace EgyptEGS.ApiClient.Model
{
    // Sub-classes

    public enum PartyType
    {
        B,
        P,
        F
    }
}
