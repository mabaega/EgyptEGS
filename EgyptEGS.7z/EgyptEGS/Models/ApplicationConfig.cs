﻿using EgyptEGS.ApiClient.Model;
using System.Security.Cryptography.X509Certificates;

namespace EgyptEGS.Models
{
    public class ApplicationConfig
    {
        public IntegrationType IntegrationType { get; set; } = IntegrationType.PreProduction;
        public string ActivityCode { get; set; } = "0910";
        public Party Issuer { get; set; }
        public string Certificate { get; set; }
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }

        public ApplicationConfig()
        {
            // Set the default values for the properties
            Issuer = new Party();
            Issuer.Type = PartyType.B;
            Issuer.Id = "382029216";
            Issuer.Name = "Issuer Company";
            Issuer.Address = new Address
            {
                BranchId = "0",
                Country = "EG",
                Governate = "Cairo",
                RegionCity = "Nasr City",
                Street = "580 Clementina Key",
                BuildingNumber = "Bldg. 0",
                PostalCode = "68030",
                Floor = "1",
                Room = "123",
                Landmark = "7660 Melody Trail",
                AdditionalInformation = "beside Townhall"
            };
        }

       
        public string ToBusinessAddress()
        {
            return $@"<div>
                    <div style='font-weight: bold; color: black; text-shadow: 2px 2px 4px #aaa;'>ISSUER</div>
                    <div style='font-weight: bold;'>{Issuer.Name}</div>
                    <div>Branch ID: {Issuer.Address.BranchId}</div>
                    <div>ID: {Issuer.Id} — Type: {Issuer.Type}</div>
                    <div>{Issuer.Address.Governate} — {Issuer.Address.RegionCity}</div>
                    <div>{Issuer.Address.Street} — Building: {Issuer.Address.BuildingNumber}</div>
                    <div>Floor: {Issuer.Address.Floor} — Room: {Issuer.Address.Room}</div>
                    <div>{Issuer.Address.Country} - {Issuer.Address.PostalCode}</div>
                    <div>{(string.IsNullOrEmpty((string?)Issuer.Address.Landmark) ? "" : $"Landmark: {Issuer.Address.Landmark}")}</div>
                    <div>{(string.IsNullOrEmpty((string?)Issuer.Address.AdditionalInformation) ? "" : $"Additional Info: {Issuer.Address.AdditionalInformation}")}</div>
                    </div>";
        }
    }

    public class CertInfoViewModel
    {
        public string BusinessDetailJson { get; set; }
        public string Api { get; set; }
        public string Token { get; set; }
        public string Referrer { get; set; }
        public ApplicationConfig AppConfig { get; set; }
        public CertInfoViewModel() { }
    }
}
