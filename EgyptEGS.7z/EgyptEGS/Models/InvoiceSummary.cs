﻿namespace EgyptEGS.Models
{
    public class InvoiceSummary
    {
        public string DocumentIssueDate { get; set; } = string.Empty;
        public string SubmissionUUID { get; set; } = string.Empty;
        public string SubmissionDate { get; set; } = string.Empty;
        public string DocumentUUID { get; set; } = string.Empty;
        public string DocumentLogId { get; set; } = string.Empty;
        public string DocumentStatus { get; set; } = string.Empty;
        public string PublicUrl { get; set; } = string.Empty;

    }
}
