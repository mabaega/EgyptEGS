using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

public static class JsonSettings
{
    public static JsonSerializerSettings Default => new JsonSerializerSettings
    {
        FloatFormatHandling = FloatFormatHandling.String,
        FloatParseHandling = FloatParseHandling.Decimal,
        DateFormatHandling = DateFormatHandling.IsoDateFormat,
        DateTimeZoneHandling = DateTimeZoneHandling.Utc,
        DateParseHandling = DateParseHandling.None,
        DateFormatString = "yyyy-MM-ddTHH:mm:ssZ",
        Converters = new JsonConverter[]
        {
            new IsoDateTimeConverter { DateTimeFormat = "yyyy-MM-ddTHH:mm:ssZ" }
        }
    };

    public static string Serialize(object value)
    {
        return JsonConvert.SerializeObject(value, Default);
    }

    public static T Deserialize<T>(string json)
    {
        return JsonConvert.DeserializeObject<T>(json, Default);
    }
}