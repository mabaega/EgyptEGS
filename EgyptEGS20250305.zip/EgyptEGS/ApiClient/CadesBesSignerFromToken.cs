﻿using System;
using System.Linq;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography.Pkcs;
using System.Text;
using Net.Pkcs11Interop.Common;
using Net.Pkcs11Interop.HighLevelAPI;
using Org.BouncyCastle.Asn1;
using Org.BouncyCastle.Asn1.Ess;
using System.Collections.Generic;

public class CadesBesSignatureGenerator
{
    public static string GenerateSignature(
        string serializedInvoice,  // Assumed to be already canonicalized
        string dllLibPath,
        string tokenPin)
    {
        // Convert canonicalized invoice to byte array
        byte[] documentBytes = Encoding.UTF8.GetBytes(serializedInvoice);

        // Initialize PKCS#11 factories
        Pkcs11InteropFactories factories = new Pkcs11InteropFactories();

        using (IPkcs11Library pkcs11Library = factories.Pkcs11LibraryFactory.LoadPkcs11Library(
            factories, dllLibPath, AppType.MultiThreaded))
        {
            // Find token slot
            ISlot slot = pkcs11Library.GetSlotList(SlotsType.WithTokenPresent).FirstOrDefault();
            if (slot == null)
                throw new Exception("No token slots found");

            using (Net.Pkcs11Interop.HighLevelAPI.ISession session = slot.OpenSession(SessionType.ReadWrite))
            {
                // Login to token
                session.Login(CKU.CKU_USER, Encoding.UTF8.GetBytes(tokenPin));

                // Search for signing certificate
                var certificateSearchAttributes = new List<IObjectAttribute>
                {
                    session.Factories.ObjectAttributeFactory.Create(CKA.CKA_CLASS, (ulong)CKO.CKO_CERTIFICATE),
                    session.Factories.ObjectAttributeFactory.Create(CKA.CKA_TOKEN, true),
                    session.Factories.ObjectAttributeFactory.Create(CKA.CKA_CERTIFICATE_TYPE, (ulong)CKC.CKC_X_509)
                };

                // Find certificate
                IObjectHandle certificateHandle = session.FindAllObjects(certificateSearchAttributes).FirstOrDefault();
                if (certificateHandle == null)
                    throw new Exception("Signing certificate not found");

                // Retrieve certificate data
                byte[] certificateBytes = session.GetAttributeValue(certificateHandle, new List<CKA> { CKA.CKA_VALUE })
                    .FirstOrDefault()?.GetValueAsByteArray();

                if (certificateBytes == null)
                    throw new Exception("Certificate data extraction failed");

                // Search for private key
                var privateKeySearchAttributes = new List<IObjectAttribute>
                {
                    session.Factories.ObjectAttributeFactory.Create(CKA.CKA_CLASS, (ulong)CKO.CKO_PRIVATE_KEY),
                    session.Factories.ObjectAttributeFactory.Create(CKA.CKA_TOKEN, true)
                };

                IObjectHandle privateKeyHandle = session.FindAllObjects(privateKeySearchAttributes).FirstOrDefault();
                if (privateKeyHandle == null)
                    throw new Exception("Private key not found");

                // Compute hash of the document
                byte[] documentHash;
                using (SHA256 sha256 = SHA256.Create())
                {
                    documentHash = sha256.ComputeHash(documentBytes);
                }

                // Manually create SignedCms
                ContentInfo contentInfo = new ContentInfo(documentBytes);
                SignedCms signedCms = new SignedCms(contentInfo, true);

                // Create X509Certificate2 from certificate bytes
                X509Certificate2 signingCertificate = new X509Certificate2(certificateBytes);

                // Manually sign the hash
                byte[] signature;
                using (RSA rsa = signingCertificate.GetRSAPrivateKey())
                {
                    if (rsa == null)
                        throw new Exception("Could not extract private key");

                    signature = rsa.SignHash(
                        documentHash,
                        HashAlgorithmName.SHA256,
                        RSASignaturePadding.Pkcs1
                    );
                }

                // Create SignerInfo manually
                SignerInfo signerInfo = new SignerInfo(
                    signingCertificate,
                    new Oid("2.16.840.1.101.3.4.2.1"), // SHA-256
                    signature
                );

                // Add SignerInfo to SignedCms
                signedCms.SignerInfos.Add(signerInfo);

                // Encode signature
                byte[] encodedSignature = signedCms.Encode();
                return Convert.ToBase64String(encodedSignature);
            }
        }
    }
}