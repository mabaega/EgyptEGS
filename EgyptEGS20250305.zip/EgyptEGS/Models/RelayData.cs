﻿using EgyptEGS.ApiClient.Model;
using EgyptEGS.Helpers;
using EgyptEGS.Utilities;
using Newtonsoft.Json;
using System.Xml.Linq;

namespace EgyptEGS.Models
{
    public class RelayData
    {
        public string Referrer { get; private set; } = string.Empty;
        public string FormKey { get; private set; } = string.Empty;
        public string Api { get; private set; } = string.Empty;
        public string Token { get; private set; } = string.Empty;
        public string InvoiceJson { get; set; } = string.Empty;
        public string BusinessDetailJson { get; set; } = string.Empty;
        public ApplicationConfig AppConfig { get; set; }
        public long EGSVersion { get; private set; }
        public ManagerInvoice ManagerInvoice { get; private set; }

        public string DocumentType { get; private set; } = "I";
        public DateTime LocalIssueDate { get; private set; } = DateTime.Now;
        public string DocumentTypeVersion { get; private set; } = "0.9";
        public string WHTSubType { get; private set; } = "W002";


        public string CurrencyCode { get; private set; } = string.Empty;
        public decimal ExchangeRate { get; private set; } = 1;
        public decimal InvoiceTotal { get; private set; } = 0;

        public Party Receiver { get; private set; }

        public string EgyptianInvoiceJson { get; set; }
        public string SerializedInvoice { get; set; }
        public InvoiceSummary InvoiceSummary { get; set; } = new InvoiceSummary();
        public List<string> CNDNReferences { get; internal set; }
        public RelayData() { }

        public RelayData(Dictionary<string, string> formData)
        {
            if (formData == null)
                throw new ArgumentNullException(nameof(formData));

            try
            {
                Referrer = Utils.GetValue(formData, "Referrer");
                FormKey = Utils.GetValue(formData, "Key");
                Api = Utils.GetValue(formData, "Api");
                Token = Utils.GetValue(formData, "Token");

                string invoiceView = Utils.GetValue(formData, "View");
                InvoiceTotal = RelayDataHelper.ParseTotalValue(invoiceView);

                var Data = Utils.GetValue(formData, "Data");

                BusinessDetailJson = RelayDataHelper.GetValueJson(Data, "BusinessDetails");
                (AppConfig,EGSVersion) = Utils.InitializeBusinessData(BusinessDetailJson);

                InvoiceJson = RelayDataHelper.FindStringValueInJson(Data, FormKey) ?? "";

                var mergedJson = RelayDataHelper.GetJsonDataByGuid(Data, FormKey);

                ManagerInvoice = JsonConvert.DeserializeObject<ManagerInvoice>(mergedJson);

                ExchangeRate = ManagerInvoice.ExchangeRate;

                InitializeInvoiceData(mergedJson);
                DetermineInvoiceType(mergedJson);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Failed to initialize RelayData", ex);
            }
        }
        
        private void InitializeInvoiceData(string jsonInvoice)
        {
            if (string.IsNullOrEmpty(jsonInvoice))
                throw new ArgumentException("Invoice data is required");

            try
            {
                CurrencyCode = RelayDataHelper.FindStringValueInJson(jsonInvoice, "Code", "Currency") ?? "EGP";

                var dateCreatedString = RelayDataHelper.GetStringCustomField2Value(jsonInvoice, ManagerCustomField.DocumentIssuedDateGuid);
                
                if (DateTime.TryParseExact(dateCreatedString, "yyyy-MM-dd HH:mm:ss", null, System.Globalization.DateTimeStyles.None, out DateTime parsedDate))
                {
                    if (parsedDate != DateTime.MinValue)
                    {
                        LocalIssueDate = parsedDate;
                    }
                }

                WHTSubType = RelayDataHelper.GetStringCustomField2Value(jsonInvoice, ManagerCustomField.WHTSubTypeGuid) ?? "W002";

                InvoiceSummary.DocumentIssueDate = LocalIssueDate;
                InvoiceSummary.SubmissionId = RelayDataHelper.GetStringCustomField2Value(jsonInvoice, ManagerCustomField.SubmissionIdGuid) ?? "";

                var submissionDate = RelayDataHelper.GetStringCustomField2Value(jsonInvoice, ManagerCustomField.DocumentIssuedDateGuid);

                if (DateTime.TryParseExact(submissionDate, "yyyy-MM-ddTHH:mm:ssZ", null, System.Globalization.DateTimeStyles.None, out DateTime parsedSubmissionDate))
                {
                    InvoiceSummary.SubmissionDate = parsedSubmissionDate;
                }

                InvoiceSummary.DocumentUUID = RelayDataHelper.GetStringCustomField2Value(jsonInvoice, ManagerCustomField.DocumentUUIDGuid) ?? "";
                InvoiceSummary.DocumentLogId = RelayDataHelper.GetStringCustomField2Value(jsonInvoice, ManagerCustomField.DocumentLongIdGuid) ?? "";
                InvoiceSummary.DocumentStatus = RelayDataHelper.GetStringCustomField2Value(jsonInvoice, ManagerCustomField.DoucmentStatusGuid) ?? "";
                InvoiceSummary.PublicUrl = RelayDataHelper.GetStringCustomField2Value(jsonInvoice, ManagerCustomField.PublicUrlGuid) ?? "";

                var receiverType = RelayDataHelper.GetStringCustomField2Value(jsonInvoice, ManagerCustomField.ReceiverTypeGuid, "InvoiceParty");
                var receiverId = RelayDataHelper.GetStringCustomField2Value(jsonInvoice, ManagerCustomField.ReceiverIdGuid, "InvoiceParty");

                Receiver = new Party
                {
                    Type = ParsePartyType(receiverType),
                    Id = receiverId,
                    Name = RelayDataHelper.GetStringCustomField2Value(jsonInvoice, ManagerCustomField.ReceiverNameGuid, "InvoiceParty"),
                    Address = new Address
                    {
                        BranchId = RelayDataHelper.GetStringCustomField2Value(jsonInvoice, ManagerCustomField.BranchIdGuid, "InvoiceParty"),
                        Country = RelayDataHelper.GetStringCustomField2Value(jsonInvoice, ManagerCustomField.CountryCodeGuid, "InvoiceParty") ?? "",
                        Governate = RelayDataHelper.GetStringCustomField2Value(jsonInvoice, ManagerCustomField.GovernorateGuid, "InvoiceParty") ?? "",
                        RegionCity = RelayDataHelper.GetStringCustomField2Value(jsonInvoice, ManagerCustomField.RegionCityGuid, "InvoiceParty") ?? "",
                        Street = RelayDataHelper.GetStringCustomField2Value(jsonInvoice, ManagerCustomField.StreetGuid, "InvoiceParty") ?? "",
                        BuildingNumber = RelayDataHelper.GetStringCustomField2Value(jsonInvoice, ManagerCustomField.BuildingNumberGuid, "InvoiceParty") ?? "",
                        PostalCode = RelayDataHelper.GetStringCustomField2Value(jsonInvoice, ManagerCustomField.PostalCodeGuid, "InvoiceParty"),
                        Floor = RelayDataHelper.GetStringCustomField2Value(jsonInvoice, ManagerCustomField.FloorGuid, "InvoiceParty"),
                        Room = RelayDataHelper.GetStringCustomField2Value(jsonInvoice, ManagerCustomField.RoomGuid, "InvoiceParty"),
                        Landmark = RelayDataHelper.GetStringCustomField2Value(jsonInvoice, ManagerCustomField.LandmarkGuid, "InvoiceParty"),
                        AdditionalInformation = RelayDataHelper.GetStringCustomField2Value(jsonInvoice, ManagerCustomField.AdditionalInformationGuid, "InvoiceParty")
                    }
                };
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Failed to initialize invoice data", ex);
            }
        }

        private PartyType ParsePartyType(string partyTypeString)
        {
            try
            {
                if (string.IsNullOrEmpty(partyTypeString))
                {
                    return PartyType.B;
                }

                string typeCode = partyTypeString.Split('—')[0].Trim();
                return (PartyType)Enum.Parse(typeof(PartyType), typeCode);
            }
            catch (Exception ex)
            {
                //throw new InvalidOperationException("Failed to get party type", ex);
                return PartyType.B;
            }
        }

        private void DetermineInvoiceType(string jsonInvoice)
        {
            if (Referrer.Contains("credit-note-view"))
            {
                DocumentType = "C";
                var salesUnitPrice = RelayDataHelper.FindStringValueInJson(jsonInvoice, "UnitPrice");
                if (decimal.TryParse(salesUnitPrice, out var salesUnitPriceDecimal) && salesUnitPriceDecimal < 0)
                {
                    DocumentType = "D";
                }
            }
        }
        public ApprovedInvoiceViewModel GetApprovedInvoiceViewModel()
        {
            var viewModel = new ApprovedInvoiceViewModel
            {
                SubmitDocumentRequestJson = EgyptianInvoiceJson,
                Referrer = Referrer,
                InvoiceSummary = InvoiceSummary,
            };
            return viewModel;
        }
        public RelayDataViewModel GetRelayDataViewModel()
        {
            RelayDataViewModel viewModel = new RelayDataViewModel();
            EgyptianInvoice egyptianInvoice = JsonConvert.DeserializeObject<EgyptianInvoice>(EgyptianInvoiceJson);

            viewModel.Referrer = Referrer;
            viewModel.FormKey = FormKey;
            viewModel.Api = Api;
            viewModel.Token = Token;
            viewModel.IntegrationType = AppConfig.IntegrationType;
            viewModel.ClientID = AppConfig.ClientId;
            viewModel.ClientSecret = AppConfig.ClientSecret;
            viewModel.InvoiceJson = InvoiceJson;
            viewModel.EgyptianInvoiceJson = EgyptianInvoiceJson;
            viewModel.SerializedInvoice = SerializedInvoice;

            viewModel.DocumentType = DocumentType;
            viewModel.DocumentTypeVersion = DocumentTypeVersion;

            //Client local time
            viewModel.IssueDate = egyptianInvoice.DateTimeIssued.ToLocalTime();

            viewModel.TotalTaxAmount = egyptianInvoice.InvoiceLines
                .SelectMany(l => l.TaxableItems)
                .Sum(t => t.Amount * (t.IsNegatif ? -1 : 1));

            viewModel.CurrencyCode = CurrencyCode;

            viewModel.InvoiceSummaryJson = JsonConvert.SerializeObject(InvoiceSummary);

            viewModel.SignServiceUrl = AppConfig.SignServiceUrl;
            
            return viewModel;
        }
    }
}