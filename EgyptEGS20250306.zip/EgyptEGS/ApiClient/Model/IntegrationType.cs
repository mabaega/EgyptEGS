﻿namespace EgyptEGS.ApiClient.Model
{
    public enum IntegrationType
    {
        [System.Runtime.Serialization.EnumMember(Value = @"PreProduction")]
        PreProduction = 0,

        [System.Runtime.Serialization.EnumMember(Value = @"Production")]
        Production = 1,

    }
}